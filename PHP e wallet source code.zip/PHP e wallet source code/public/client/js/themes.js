
// tooltip

$('.btn').tooltip();
$('.fa').tooltip();

// popover

$('.btn').popover();